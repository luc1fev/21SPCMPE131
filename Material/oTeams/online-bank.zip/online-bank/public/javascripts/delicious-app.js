import '../sass/style.scss';

import { $, $$ } from './modules/bling';
import makemap from './modules/map';


makemap($('#map'));
